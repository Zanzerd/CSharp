using System.Windows.Forms;

namespace RefactorMe
{
    public class Program
    {
        public static void Main()
        {
            Application.Run(new MainForm(800, 600));
        }
    }
}