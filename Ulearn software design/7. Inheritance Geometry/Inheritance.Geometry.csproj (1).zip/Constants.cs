namespace Inheritance.Geometry
{
    public static class Constants
    {
        public static double Inaccuracy { get; } = 0.0001;
    }
}
