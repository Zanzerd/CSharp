﻿namespace Antiplagiarism
{
    public enum TokenType
    {
        Common,
        Specific
    }
}