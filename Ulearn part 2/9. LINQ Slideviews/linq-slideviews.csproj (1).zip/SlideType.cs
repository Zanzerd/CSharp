﻿namespace linq_slideviews
{
	public enum SlideType
	{
		Theory,
		Exercise,
		Quiz
	}
}